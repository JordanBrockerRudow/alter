# Minimal Carousel with horizontal scroll + snap, mobile & mouse friendly

A Pen created on CodePen.io. Original URL: [https://codepen.io/fredericrous/pen/xxVXJYX](https://codepen.io/fredericrous/pen/xxVXJYX).

A scrollable carousel in few lines of JS and CSS.
You can scroll with your fingers or click and drag. The div snaps to the center
Does not use any library like slick, owl carousel, tiny-slider, flickity, ... 