# #AppleEvent Like Animation (css only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Zaku/pen/gOrjOGp](https://codepen.io/Zaku/pen/gOrjOGp).

Twitter #AppleEvent css only like animation

Visit https://hashflaggallery.com to see all animated hashflags from twitter