# Animated folder micro-interaction

A Pen created on CodePen.io. Original URL: [https://codepen.io/Letscallitluv/pen/abqgEww](https://codepen.io/Letscallitluv/pen/abqgEww).

A recreation of a micro-interaction designed by Lu Yuhang
https://dribbble.com/shots/11983664-Folder-Open-Animation