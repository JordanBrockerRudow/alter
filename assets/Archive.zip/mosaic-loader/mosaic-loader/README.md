# Mosaic Loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/crayon-code/pen/eYdVLJo](https://codepen.io/crayon-code/pen/eYdVLJo).

Watch me code this on YouTube: https://youtu.be/GmjnDw_DQD8