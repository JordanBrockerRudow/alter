# Text with background image GSAP animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/Letscallitluv/pen/wvyLPGp](https://codepen.io/Letscallitluv/pen/wvyLPGp).

