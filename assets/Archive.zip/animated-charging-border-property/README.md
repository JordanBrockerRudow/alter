# Animated Charging Border (@property)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jh3y/pen/jOVNOeg](https://codepen.io/jh3y/pen/jOVNOeg).

